<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - Hệ thống Văn phòng phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .login-card {
            width: 400px;
        }
        .btn-gradient {
            background: linear-gradient(to right, #8b3dff, #722ed1);
            border: none;
            color: white;
        }
        .btn-gradient:hover {
            opacity: 0.9;
            color: white;
        }
    </style>
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">
    <div class="login-card p-4 shadow-sm bg-white rounded-4">
        <h2 class="text-center fw-bold mb-1">Đăng nhập</h2>
        <p class="text-center text-muted mb-4">Chào mừng bạn quay trở lại!</p>
        
        <form action="XuLyDangNhap.php" method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Tên đăng nhập</label>
                <div class="input-group border rounded-3 p-2">
                    <span class="input-group-text bg-transparent border-0">
                        <i class="fa-regular fa-user text-muted"></i>
                    </span>
                    <input type="text" name="tai_khoan" class="form-control border-0 shadow-none" placeholder="Nhập tài khoản" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Mật khẩu</label>
                <div class="input-group border rounded-3 p-2">
                    <span class="input-group-text bg-transparent border-0">
                        <i class="fa-solid fa-lock text-muted"></i>
                    </span>
                    <input type="password" name="mat_khau" class="form-control border-0 shadow-none" placeholder="Nhập mật khẩu" required>
                    <span class="input-group-text bg-transparent border-0">
                        <i class="fa-regular fa-eye text-muted"></i>
                    </span>
                </div>
            </div>
            <div class="d-flex justify-content-between mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="remember">
                    <label class="form-check-label text-muted" for="remember">Ghi nhớ</label>
                </div>
                <a href="#" class="text-decoration-none small" style="color: #8b3dff;">Quên mật khẩu?</a>
            </div>
            
            <button type="submit" class="btn btn-gradient w-100 py-2 rounded-3 fw-bold mb-4">Đăng nhập</button>
            
            <p class="text-center mb-0 text-muted">
                Chưa có tài khoản? 
                <a href="ĐangKy.php" class="text-decoration-none fw-bold" style="color: #8b3dff;">Đăng ký</a>
            </p>
        </form>
    </div>
</body>
</html>